package exemplo;

//Cria��o da classe
public final class Janela {
	
	//Atributos privados
	private static final Janela INSTANCE = new Janela();
	private static final String Teste = "Exemplo Singleton Privado";
	
	//Atributo p�blico
	public static final String Singleton = "Exemplo Singleton P�blico";
	
	//Construtor privado
	private Janela() {
		
	}
	
	//M�todo p�blico est�tico realizando o primeiro e �nico acesso necess�rio nesse tipo de aplica��o
	public static Janela getInstance() {
		return INSTANCE;
	}
	
	//Execu��o desse m�todo de qualquer parte do projeto
	public static void Abrir() {
		System.out.println("Abrir Janela!");
	}
	
	//Execu��o desse m�todo de qualquer parte do projeto
	public static void Fechar() {
		System.out.println("Abrir Fechar!");
	}

}
